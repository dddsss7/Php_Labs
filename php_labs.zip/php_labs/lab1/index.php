<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Laborator PHP 1</title>
</head>

<body>

<h1>Laborator de laborator nr. 1 - PHP</h1>

<h2>1. Echo și Print</h2>

<?php

echo "Acesta este un mesaj afișat cu echo.";
echo "<br>";

print "Acesta este un mesaj afișat cu print.";
print "<br>";


echo "<h2>2. Variabile și tipuri de date</h2>";

$nume = "Dan";
$varsta = 19;
$inaltime = 1.95;
$student = true;

echo "Nume: " . $nume . "<br>";
echo "Vârsta: " . $varsta . "<br>";
echo "Înălțimea: " . $inaltime . " m<br>";
echo "Student: " . $student . "<br>";


echo "<h2>3. Concatenarea șirurilor</h2>";

$universitate = "USM";

echo "Numele meu este " . $nume . " și studiez la " . $universitate . ".<br>";


echo "<h2>4. Data și ora curentă</h2>";

echo "Data curentă: " . date("d.m.Y") . "<br>";
echo "Ora curentă: " . date("H:i:s") . "<br>";


echo "<h2>5. Conținut generat de PHP</h2>";

echo "<p>Acest text a fost generat de PHP pe server.</p>";

?>

<h2>6. JavaScript - Client-side</h2>

<script>
    alert("Salut! Acest mesaj este afișat de JavaScript în browser.");
</script>

<button onclick="mesaj()">Apasă aici</button>

<script>
    function mesaj() {
        alert("Ai apăsat butonul!");
    }
</script>

<h2>7. HTML</h2>

<p>Acest text este scris direct în HTML.</p>

</body>
</html>