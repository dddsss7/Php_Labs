<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Lucrare de laborator nr. 2</title>
</head>
<body>

<h1>Lucrare de laborator nr. 2</h1>

<?php

// 1. Afișare dinamică într-un document web

$numeUtilizator = "Danu";
$anNastere = 2006;

$anCurent = date("Y");
$varsta = $anCurent - $anNastere;

echo "<h2>Salut, $numeUtilizator!</h2>";
echo "<p>Ai $varsta ani.</p>";


// 2. Lucrul cu tablouri și structuri repetitive

$student = [
    "nume" => "Samoila",
    "prenume" => "Dan",
    "grupa" => "IA-231",
    "note" => [9, 8, 10, 7, 6, 4]
];

echo "<h2>Datele studentului</h2>";

echo "<p>Nume: " . $student["nume"] . "</p>";
echo "<p>Prenume: " . $student["prenume"] . "</p>";
echo "<p>Grupa: " . $student["grupa"] . "</p>";

echo "<h3>Note:</h3>";
echo "<ul>";

foreach ($student["note"] as $nota) {
    echo "<li>$nota</li>";
}

echo "</ul>";


// 3. Funcție cu parametri și valoare returnată

function calculeazaMedia($note)
{
    return array_sum($note) / count($note);
}

$media = calculeazaMedia($student["note"]);

echo "<h2>Media studentului</h2>";
echo "<p>Media: " . number_format($media, 2) . "</p>";


// 4. Instrucțiuni condiționale

if ($media >= 9) {
    $calificativ = "Excelent";
} elseif ($media >= 7) {
    $calificativ = "Bine";
} elseif ($media >= 5) {
    $calificativ = "Suficient";
} else {
    $calificativ = "Insuficient";
}

echo "<p>Calificativ: $calificativ</p>";

if ($media >= 8.5) {
    echo "<p>Felicitări! Studentul are o medie foarte bună.</p>";
}


// 5. Structuri repetitive cu aplicabilitate practică

$numarPromovate = 0;
$numarNepromovate = 0;

echo "<h2>Note promovate</h2>";
echo "<ul>";

foreach ($student["note"] as $nota) {

    if ($nota >= 5) {
        echo "<li>$nota</li>";
        $numarPromovate++;
    } else {
        $numarNepromovate++;
    }
}

echo "</ul>";

echo "<p>Număr note promovate: $numarPromovate</p>";
echo "<p>Număr note nepromovate: $numarNepromovate</p>";


// 6. Funcție anonimă

$verificaNota = function ($nota) {

    if ($nota >= 5) {
        return "Promovat";
    } else {
        return "Respins";
    }
};

echo "<h2>Rezultatul fiecărei note</h2>";

foreach ($student["note"] as $nota) {

    $rezultat = $verificaNota($nota);

    echo "<p>Nota $nota: $rezultat</p>";
}

?>

</body>
</html>